import os
import gdown
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import torch.nn.functional as F
import time

def get_rays(height, width, intrinsics, w_R_c, w_T_c):
    """
    Compute the origin and direction of rays passing through all pixels of an image (one ray per pixel).

    Args:
    height: the height of an image.
    width: the width of an image.
    intrinsics: camera intrinsics matrix of shape (3, 3).
    w_R_c: Rotation matrix of shape (3,3) from camera to world coordinates.
    w_T_c: Translation vector of shape (3,1) that transforms from camera to world coordinates.

    Returns:
    ray_origins (torch.Tensor): A tensor of shape (height, width, 3) denoting the centers of
      each ray. Note that desipte that all ray share the same origin, here we ask you to return
      the ray origin for each ray as (height, width, 3).
    ray_directions (torch.Tensor): A tensor of shape (height, width, 3) denoting the
      direction of each ray.
    """

    device = intrinsics.device
    ray_directions = torch.zeros((height, width, 3), device=device)  # placeholder
    ray_origins = torch.zeros((height, width, 3), device=device)  # placeholder

    #############################  TODO 2.1 BEGIN  ##########################
    y, x = torch.meshgrid(
        torch.arange(height, device=device), torch.arange(width, device=device)
    )
    pixel_coords = torch.stack(
        [x, y, torch.ones_like(x)], dim=-1
    ).float()  # Shape：[height, width, 3]

    # Transform the directions to world coordinates using the intrinsics and the rotation matrix
    camera_coords = torch.matmul(
        torch.linalg.inv(intrinsics).unsqueeze(0).unsqueeze(0),
        pixel_coords.unsqueeze(-1),
    )
    camera_coords = camera_coords.squeeze(-1)  # Shape：[height, width, 3]
    ray_directions = torch.matmul(
        w_R_c.unsqueeze(0).unsqueeze(0), camera_coords.unsqueeze(-1)
    )
    ray_directions = ray_directions.squeeze(-1)  # Shape：[height, width, 3]
    ray_directions = torch.nn.functional.normalize(ray_directions, dim=-1)  # Normalize the directions

    # The ray origins in world coordinates are the same and given by the translation vector
    ray_origins[:] = w_T_c

    #############################  TODO 2.1 END  ############################
    return ray_origins, ray_directions


def plot_all_poses(poses):
    #############################  TODO 2.1 BEGIN  ############################
    origins = []  # To store all origins
    directions = []  # To store all directions

    for pose in poses:
        # Extract the translation part as the origin
        origin = pose[:3, 3]
        origins.append(origin)

        # Assume intrinsic matrix and image center coordinates (u0, v0)
        focal_length = 1  # Assume a focal length of 1, adjust as necessary
        u0, v0 = 0, 0  # Assume image center coordinates are (0, 0), adjust as necessary
        direction = np.linalg.inv(pose[:3, :3]) @ np.array([u0, v0, focal_length])
        direction = direction / np.linalg.norm(
            direction
        )  # Normalize the direction vector
        directions.append(direction)

    origins = np.stack(origins)
    directions = np.stack(directions)

    #############################  TODO 2.1 END  ############################

    ax = plt.figure(figsize=(12, 8)).add_subplot(projection="3d")
    _ = ax.quiver(
        origins[..., 0].flatten(),
        origins[..., 1].flatten(),
        origins[..., 2].flatten(),
        directions[..., 0].flatten(),
        directions[..., 1].flatten(),
        directions[..., 2].flatten(),
        length=0.12,
        normalize=True,
    )
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("z")
    plt.show()





def stratified_sampling(ray_origins, ray_directions, near, far, samples):
    """
    Sample 3D points on the given rays. The near and far variables indicate the bounds of sampling range.

    Args:
    ray_origins: Origin of each ray in the "bundle" as returned by the
      get_rays() function. Shape: (height, width, 3).
    ray_directions: Direction of each ray in the "bundle" as returned by the
      get_rays() function. Shape: (height, width, 3).
    near: The 'near' extent of the bounding volume.
    far:  The 'far' extent of the bounding volume.
    samples: Number of samples to be drawn along each ray.

    Returns:
    ray_points: Query 3D points along each ray. Shape: (height, width, samples, 3).
    depth_points: Sampled depth values along each ray. Shape: (height, width, samples).
    """

    #############################  TODO 2.2 BEGIN  ############################
    # Get the device and dtype from the input to create new tensors
    device = ray_origins.device
    dtype = ray_origins.dtype

    # Create evenly spaced depth samples within the range [near, far]
    depth_step = (far - near) / samples
    depth_points = torch.arange(near, far, depth_step, device=device, dtype=dtype)
    depth_points = depth_points.unsqueeze(0).unsqueeze(0)
    depth_points = depth_points.expand(ray_origins.shape[0], ray_origins.shape[1], -1)

    # Compute the sampled points along the direction of the rays
    ray_points = ray_origins.unsqueeze(2) + ray_directions.unsqueeze(
        2
    ) * depth_points.unsqueeze(-1)

    #############################  TODO 2.2 END  ############################
    return ray_points, depth_points


class nerf_model(nn.Module):

    """
    Define a NeRF model comprising eight fully connected layers and following the
    architecture described in the NeRF paper.
    """

    def __init__(self, filter_size=256, num_x_frequencies=6, num_d_frequencies=3):
        super().__init__()

        #############################  TODO 2.3 BEGIN  ############################
        # for autograder compliance, please follow the given naming for your layers
        self.L_pos = num_x_frequencies
        self.L_dir = num_d_frequencies

        # Calculate the lengths of encoded position and direction vectors
        pos_enc_feats = 3 + 3 * 2 * self.L_pos
        dir_enc_feats = 3 + 3 * 2 * self.L_dir

        # Define MLP layers
        self.layers = nn.ModuleDict(
            {
                "layer_1": nn.Linear(pos_enc_feats, filter_size),
                "layer_2": nn.Linear(filter_size, filter_size),
                "layer_3": nn.Linear(filter_size, filter_size),
                "layer_4": nn.Linear(filter_size, filter_size),
                "layer_5": nn.Linear(filter_size, filter_size),
                "layer_6": nn.Linear(filter_size + pos_enc_feats, filter_size),
                "layer_7": nn.Linear(filter_size, filter_size),
                "layer_8": nn.Linear(filter_size, filter_size),
                "sigma_layer": nn.Linear(filter_size, 1),
                "feature_vector": nn.Linear(filter_size, filter_size),
                "pre_final_layer": nn.Linear(
                    dir_enc_feats + filter_size, filter_size // 2
                ),
                "final_layer": nn.Linear(filter_size // 2, 3),
            }
        )

    def forward(self, x, d):
        # Forward pass through early layers
        h = F.relu(self.layers["layer_1"](x))
        h = F.relu(self.layers["layer_2"](h))
        h = F.relu(self.layers["layer_3"](h))
        h = F.relu(self.layers["layer_4"](h))

        # Skip connection after the fifth layer
        skip = torch.cat([x, F.relu(self.layers["layer_5"](h))], dim=-1)

        # Remaining layers
        h = F.relu(self.layers["layer_6"](skip))
        h = F.relu(self.layers["layer_7"](h))
        h = self.layers["layer_8"](h)  # No activation

        # Predict volume density sigma
        sigma = F.relu(self.layers["sigma_layer"](h))

        # Additional layers for color prediction
        feature_vector = F.relu(self.layers["feature_vector"](h))

        # Concatenate feature vector with direction encoding
        h = torch.cat([d, feature_vector], dim=-1)
        h = F.relu(self.layers["pre_final_layer"](h))
        rgb = torch.sigmoid(self.layers["final_layer"](h))

        #############################  TODO 2.3 END  ############################
        return rgb, sigma

def get_batches(ray_points, ray_directions, num_x_frequencies, num_d_frequencies):
    def get_chunks(inputs, chunksize=2**15):
        """
        This fuction gets an array/list as input and returns a list of chunks of the initial array/list
        """
        return [inputs[i : i + chunksize] for i in range(0, inputs.shape[0], chunksize)]

    """
    This function returns chunks of the ray points and directions to avoid memory errors with the
    neural network. It also applies positional encoding to the input points and directions before
    dividing them into chunks, as well as normalizing and populating the directions.
    """
    #############################  TODO 2.3 BEGIN  ############################
    # Normalize ray directions and repeat for each point along the ray
    norm_ray_directions = F.normalize(ray_directions, dim=-1)
    norm_ray_directions = norm_ray_directions.unsqueeze(2).expand_as(ray_points)

    # Apply positional encoding to ray points and directions
    encoded_ray_points = positional_encoding(ray_points, num_x_frequencies)
    encoded_ray_directions = positional_encoding(norm_ray_directions, num_d_frequencies)

    # Flatten the vectors
    flat_ray_points = encoded_ray_points.reshape(-1, encoded_ray_points.shape[-1])
    flat_ray_directions = encoded_ray_directions.reshape(
        -1, encoded_ray_directions.shape[-1]
    )

    # Divide into chunks
    ray_points_batches = get_chunks(flat_ray_points)
    ray_directions_batches = get_chunks(flat_ray_directions)

    #############################  TODO 2.3 END  ############################

    return ray_points_batches, ray_directions_batches

def volumetric_rendering(rgb, s, depth_points):
    """
    Differentiably renders a radiance field, given the origin of each ray in the
    "bundle", and the sampled depth values along them.

    Args:
    rgb: RGB color at each query location (X, Y, Z). Shape: (height, width, samples, 3).
    sigma: Volume density at each query location (X, Y, Z). Shape: (height, width, samples).
    depth_points: Sampled depth values along each ray. Shape: (height, width, samples).

    Returns:
    rec_image: The reconstructed image after applying the volumetric rendering to every pixel.
    Shape: (height, width, 3)
    """

    #############################  TODO 2.4 BEGIN  ############################
    # Calculate the deltas (distance between adjacent sampled depth values)
    deltas = depth_points[..., 1:] - depth_points[..., :-1]
    # Append a very large value to the last delta to ensure that it does not affect the result
    deltas = torch.cat(
        [
            deltas,
            torch.tensor([1e10], device=deltas.device).expand(deltas[..., :1].shape),
        ],
        -1,
    )

    # Ensure sigma is passed through a ReLU to avoid negative densities
    sigma = F.relu(s)
    # Calculate the negative exponent for transmittance
    alpha = 1.0 - torch.exp(-sigma * deltas)
    # Calculate the transmittance T_i for each sample point
    T = torch.cumprod(
        torch.cat([torch.ones_like(sigma[..., :1]), 1.0 - alpha + 1e-10], -1), -1
    )[..., :-1]

    # Calculate the weighted colors
    weights = alpha * T
    rec_image = torch.sum(weights.unsqueeze(-1) * rgb, -2)

    #############################  TODO 2.4 END  ############################

    return rec_image



def one_forward_pass(
    height,
    width,
    intrinsics,
    pose,
    near,
    far,
    samples,
    model,
    num_x_frequencies,
    num_d_frequencies,
):
    #############################  TODO 2.5 BEGIN  ############################
    # Step 1: Compute all the rays from the image
    ray_origins, ray_directions = get_rays(
        height, width, intrinsics, pose[:3, :3], pose[:3, 3]
    )

    # Step 2: Sample points from the rays
    ray_points, depth_points = stratified_sampling(
        ray_origins, ray_directions, near, far, samples
    )

    # Step 3: Divide data into batches to avoid memory errors
    ray_points_batches, ray_directions_batches = get_batches(
        ray_points, ray_directions, num_x_frequencies, num_d_frequencies
    )

    all_rgb = []
    all_sigma = []
    for points_batch, dirs_batch in zip(ray_points_batches, ray_directions_batches):
        rgb, sigma = model(points_batch, dirs_batch)
        all_rgb.append(rgb)
        all_sigma.append(sigma.view(-1, samples))  # Reshape sigma within each batch

    # Concatenate along the first dimension and then reshape to match the grid
    rgb = torch.cat(all_rgb, dim=0).view(height, width, samples, -1)
    sigma = torch.cat(all_sigma, dim=0).view(height, width, samples)

    # Step 5: Apply volumetric rendering to obtain the reconstructed image
    rec_image = volumetric_rendering(rgb, sigma, depth_points)
    #############################  TODO 2.5 END  ############################

    return rec_image





